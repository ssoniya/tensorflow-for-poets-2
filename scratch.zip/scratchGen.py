## SCRIPT to generate SCRATCH MARKS on Image ##
import os
import shutil
import cv2
import numpy as np
import math
import random
from scipy import ndimage
from matplotlib import pyplot as ple
import traceback

# Get Random location to insert scratch on image
def getRandomCords(yBounds,xBounds,h,w):
	# Parameters-
	#	yBounds: y axis boundary range of background image
	#	xBounds: x axis boundary range of background image
	#	h: height of scratch
	#	w: width of scratch
	# Returns x,y coordinate of background image where scratch should be overlayed
	
    y = np.random.random_integers(yBounds[0],yBounds[1])
    x = np.random.random_integers(xBounds[0],xBounds[1])

    if y + h > yBounds[1]:
       while y+h>yBounds[1]:
           y =np.random.random_integers(yBounds[0],yBounds[1])
    if x + w > xBounds[1]:
        while x + w > xBounds[1]:
            x =np.random.random_integers(xBounds[0],xBounds[1])
    return x,y

# Get a portion of scratch mark used based on x and y ratios
def getPortion(scratch,alpha,xr=0.75,yr=0.75):
	# Parameters-
	#	scratch: scratch image
	#	alpha: corresponding mask image of scratch
	#	xr: width ratio
	#	yr: height ratio
	# Returns portion of patch and alpha selected based on input parameters

	h,w=scratch.shape[:2]
	xpixs = math.floor(w*xr)
	ypixs = math.floor(h * yr)
	y = np.random.random_integers(0, h)
	x = np.random.random_integers(0, w)

	if y + ypixs > h:
		while y + ypixs > h:
			y =np.random.random_integers(0,h)
	if x + xpixs > w:
		while x + xpixs > w:
			x =np.random.random_integers(0,w)
	patch=scratch[y:y+ypixs,x:x+xpixs]
	pAlpha=alpha[y:y+ypixs,x:x+xpixs]
	return patch,pAlpha

# Apply rotation and display random pixels based on percent passed
def getPatch(scratch,alpha,angle,percent=0.75):
	# Parameters-
	#	scratch: scratch image
	#	alpha: corresponding mask image of scratch
	#	angle: angle of rotation for scratch
	#	percent: percent of total pixels of scratch to be considered randomly;remaining will be copied as such from background
	# Returns transformed patch and alpha modified based on input parameters
	
    rotated = ndimage.rotate(scratch, angle)
    ralpha = ndimage.rotate(alpha, angle)
    h,w=ralpha.shape[:2]
    cordList=[]
    for i in range(0,h):
        for j in range(0,w):
            cordList.append([i,j])
    random.shuffle(cordList)
    l=len(cordList)
    skipLen=math.floor(l*(1-percent))
    for n in range(0,skipLen):
        [i,j]=cordList[n]
        ralpha[i,j]=0
    return rotated,ralpha

# Main program
if __name__ == '__main__':
	try:
		# Output directory to save generated images
		outLoc='scratchImgs'
		if os.path.isdir(outLoc):
			shutil.rmtree(outLoc)
		os.makedirs(outLoc)
		
		# Values allowed
		angleList=[i for i in range(0,45,3)]
		perCentList=[0.7,0.8,0.9,1.0]
		
		#Using scratch 1
		scratch1 = cv2.imread("scratch1.png",0)
		alpha1 = cv2.imread("mask1.png",0)
		scratch1 = scratch1.astype(float)
		alpha1 = alpha1.astype(float) / 255
		alpha1 = 1.0-alpha1
		
		yBounds=[392,983]
		xBounds=[973,2145]
		background = cv2.imread("61326(FrontSide)-OK-(6).jpg",0)
		background = background.astype(float)
		
		for num in range(0,46):
			bkg=background.copy()
			angle=np.random.choice(angleList)
			xRat=np.random.choice(perCentList)
			yRat=np.random.choice(perCentList)
			per=np.random.choice(perCentList)
			
			patchPor,alphaPor=getPortion(scratch1,alpha1,xRat,yRat)
			patchT,alphaT=getPatch(patchPor,alphaPor,angle,per)
			h,w=patchT.shape[:2]

			x,y = getRandomCords(yBounds,xBounds,h,w)
			for i in range(0,h):
				for j in range(0,w):
					bkg[y + i,x + j]=alphaT[i,j]*patchT[i,j]+(1.0-alphaT[i,j])*bkg[y+i,x+j]
			cv2.imwrite(os.path.join(outLoc,'scratch1_'+str(num)+'.png'),bkg)
			
		#Using scratch 2
		num=1
		yx=[840,1580]
		scratch2 = cv2.imread("scratch2.png",0)
		alpha2 = cv2.imread("mask2.png",0)
		scratch2 = scratch2.astype(float)
		alpha2 = alpha2.astype(float) / 255
		alpha2 = 1.0-alpha2
		
		x,y = yx
		background = cv2.imread("61326(FrontSide)-OK-(6).jpg",0)
		background = background.astype(float)
		for num in range(1,16):
			backgnd=background.copy()
			per=np.random.choice(perCentList)		
			if num<8:
				y+=10;x-=8
			else:
				y+=10;x+=5
			
			patch2T,alpha2T=getPatch(scratch2,alpha2,0,per)
			h,w=patch2T.shape[:2]
		
			for i in range(0,h):
				for j in range(0,w):
					backgnd[y + i,x + j]=alpha2T[i,j]*patch2T[i,j]+(1.0-alpha2T[i,j])*backgnd[y+i,x+j]
			cv2.imwrite(os.path.join(outLoc,'scratch2_'+str(num)+'.png'),backgnd)
		
	except:
		print(traceback.print_exc())