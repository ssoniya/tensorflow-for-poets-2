README FILE for scratchGen.py
-------------------------------

Problem Statement-
Generate multiple scratch mark images.

Approach-
Two scratch marks are taken from 61326-SC-(20).JPG image, named as scratch1.png and scratch2.png in zipped folder.
Their corresponding masks (mask1.png and mask2.png respectively) are generated for transparency.
These two steps were manually done using Paint.

Next step is to overlay these scratches at random positions in front side images.
1) Front side image (61326(FrontSide)-OK-(6).jpg) is read as background image.
2) First scratch1 is used to generate 45 images in loop with varyng parameters passed.
3) After it, scratch2 which is more on boundary edge, is used to generate images.
 
Functions-
1) getRandomCords(yBounds,xBounds,h,w): Used for scratch1 as scratch1 is supposed to be in upper half portion.
2) getPortion(scratch,alpha,xr=0.75,yr=0.75): Considers only a part of scratch to be overlayed based on input parameters.
3) getPatch(scratch,alpha,angle,percent=0.75):Adds rotation and modifies alpha based on percent of pixels to be considered.

In the given script, variations introduced based on-
1) Location of placement of scratch marks
2) Angle/rotation of scratch mark
3) Portion of scratch mark considered 
4) Pixel percent of scratch mark considered

Experiment Observation-
Generated total 61 images, 19 given in training dataset = 80 scratch mark images.
Retrained network with 2 class problem-FrontSide(86 images) and ScratchMarks(19 and 80)
Observed reduction in loss earlier for the run with generated images.

Note:
Scratch1 location is kept in upper half as it's observed in that area while scratch2 is an edge mark. Hence it's location is varied in different way in script.